Create ChatGPT pet row `failed` for `cyberpunk-system-doctor`: exactly 8 full-body frames in one horizontal strip on flat pure cyan #00FFFF.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: Use all three user reference views as mandatory identity. Adult human male cyberpunk doctor, brown swept hair, black rectangular glasses, short beard, white long cybernetic coat, graphite armor trousers and boots, neon violet pink attached light panels. Preserve human adult proportions and reference appearance, no toy or robot redesign. No new props or text. Transparent background; cyan chroma if needed since pink is character color.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Blocked/failed loop: slumped or deflated reaction with sad or closed eyes.

State requirements:
- Show failure through slumped pose, drooping ears/limbs, closed or sad eyes, and lower body position.
- Tears, small smoke puffs, or tiny stars are allowed only if attached to or overlapping the pet silhouette and kept inside the same frame slot.
- Do not draw red X marks, floating symbols, detached stars, separated smoke clouds, falling tear drops, dust, or other loose effects.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #00FFFF colors in the pet.
