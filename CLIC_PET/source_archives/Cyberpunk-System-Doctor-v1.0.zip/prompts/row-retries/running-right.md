Create ChatGPT pet row `running-right` for `cyberpunk-system-doctor`: exactly 8 full-body frames in one horizontal strip on flat pure cyan #00FFFF.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: Use all three user reference views as mandatory identity. Adult human male cyberpunk doctor, brown swept hair, black rectangular glasses, short beard, white long cybernetic coat, graphite armor trousers and boots, neon violet pink attached light panels. Preserve human adult proportions and reference appearance, no toy or robot redesign. No new props or text. Transparent background; cyan chroma if needed since pink is character color.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Dragging-right loop: show directional movement to the right through body and limb poses only.

State requirements:
- Show directional drag movement to the right through body, limb, and prop movement only.
- The row must unmistakably face and travel right.
- The movement cadence must alternate visibly across the 8 frames instead of repeating one nearly static stride.
- Do not draw speed lines, dust clouds, floor shadows, motion trails, or detached motion effects.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #00FFFF colors in the pet.
