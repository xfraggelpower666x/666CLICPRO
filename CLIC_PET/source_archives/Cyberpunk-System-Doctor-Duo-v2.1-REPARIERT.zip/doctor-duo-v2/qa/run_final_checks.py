#!/usr/bin/env python3
"""Gebündelte finale Prüfungen; erst nach visueller Freigabe starten."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

RUN = Path(__file__).resolve().parents[1]
SCRIPTS = Path('/root/.codex/plugins/cache/openai-curated-remote/work-pets/0.1.6/skills/create-pet/scripts')
RAW = RUN / 'final/spritesheet-extended-raw.png'
FINAL = RUN / 'final/spritesheet-extended.png'
QA = RUN / 'qa'
LOGS = QA / 'final-check-logs'
MARKER = QA / 'despill-once-started.json'

def invoke(name, *args):
    command = [sys.executable, str(SCRIPTS / (name + '.py')), *map(str, args)]
    result = subprocess.run(command, cwd=RUN, text=True, capture_output=True)
    (LOGS / (name + '.json')).write_text(json.dumps({'command': command, 'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}, indent=2))
    print(result.stdout, end='')
    print(result.stderr, end='', file=sys.stderr)
    if result.returncode:
        raise SystemExit(result.returncode)

def main():
    if '--parent-approved' not in sys.argv:
        raise SystemExit('Erst nach Elternfreigabe mit --parent-approved ausführen.')
    if not RAW.is_file():
        raise SystemExit('Freigegebener Rohatlas fehlt.')
    if MARKER.exists() or FINAL.exists():
        raise SystemExit('Despill bereits gestartet oder finale Datei vorhanden; kein zweiter Durchlauf.')
    LOGS.mkdir(parents=True, exist_ok=True)
    with MARKER.open('x') as file:
        json.dump({'raw_sha256': hashlib.sha256(RAW.read_bytes()).hexdigest()}, file)
    invoke('despill_chroma_edges', RAW, '--output', FINAL, '--json-out', QA / 'chroma-despill-extended.json', '--chroma-key', '#00FF00')
    invoke('validate_atlas', FINAL, '--require-v2', '--chroma-key', '#00FF00', '--json-out', RUN / 'final/validation-extended.json')
    validation = json.loads((RUN / 'final/validation-extended.json').read_text())
    if validation.get('ok') is not True:
        raise SystemExit('Atlasbericht enthält kein ok:true.')
    invoke('make_contact_sheet', FINAL, '--output', QA / 'contact-sheet-extended.png')
    invoke('make_direction_qa_sheet', FINAL, '--output', QA / 'direction-qa-sheet.png')
    invoke('measure_direction_continuity', FINAL, '--json-out', QA / 'look-continuity.json')
    invoke('make_direction_blind_qa_sheet', FINAL, '--output', QA / 'direction-blind-qa-sheet.png', '--answer-key', QA / 'direction-blind-answer-key.json')
    (QA / 'final-check-bytes.json').write_text(json.dumps({'sha256': hashlib.sha256(FINAL.read_bytes()).hexdigest(), 'byte_length': FINAL.stat().st_size}, indent=2))
    print('Gebündelte Struktur- und QA-Artefakte erstellt. Semantik, Blindprüfung und Qualitygate bleiben separat.')

if __name__ == '__main__':
    main()
