import importlib.util,sys,json
from pathlib import Path
skill=Path('/root/.codex/plugins/cache/openai-curated-remote/work-pets/0.1.6/skills/create-pet/scripts')
sys.path.insert(0,str(skill))
spec=importlib.util.spec_from_file_location('extract',skill/'extract_strip_frames.py'); mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
original=mod.component_frame_groups
report=[]
def duo_groups(strip,count):
    components=mod.connected_components(strip)
    seeds=sorted(sorted(components,key=lambda c:c['area'],reverse=True)[:count],key=lambda c:c['center_x'])
    ids={id(c) for c in seeds}; groups=[[c] for c in seeds]
    juniors=sorted([c for c in components if id(c) not in ids and c['area']>=max(c['area'] for c in seeds)*.12],key=lambda c:c['center_x'])
    for junior in juniors:
        candidates=[i for i,adult in enumerate(seeds) if adult['center_x']<junior['center_x']]
        if not candidates: raise RuntimeError('Junior before first doctor')
        i=max(candidates); adult=seeds[i]
        groups[i].append(junior);ids.add(id(junior))
        report.append({'frame':i,'adult_bbox':adult['bbox'],'junior_bbox':junior['bbox'],'assignment':'detached junior assigned to preceding observed doctor component'})
    for c in components:
        if id(c) in ids or c['area']<max(c['area'] for c in seeds)*.002: continue
        i=min(range(count),key=lambda j:min(abs(k['center_x']-c['center_x']) for k in groups[j]));groups[i].append(c)
    return groups
mod.component_frame_groups=duo_groups
sys.argv=['extract','--decoded-dir','decoded','--output-dir','qa/rows/running-left/frames','--states','running-left','--method','components','--chroma-key','#00FF00'];mod.main()
Path('qa/rows/running-left/grouping-correction.json').write_text(json.dumps({'method':'bundled connected components and shared fit; duo pairing by observed ordered components','frames':report},indent=2))
p=Path('qa/rows/running-left/frames/frames-manifest.json'); data=json.loads(p.read_text());data['duo_grouping_correction']='../grouping-correction.json';p.write_text(json.dumps(data,indent=2))
