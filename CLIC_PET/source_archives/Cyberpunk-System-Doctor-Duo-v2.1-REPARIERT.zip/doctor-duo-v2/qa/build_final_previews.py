#!/usr/bin/env python3
"""Deterministische Vorschauen aus dem unveränderten finalen Atlas."""
from pathlib import Path
import hashlib, json, subprocess, sys
from PIL import Image, ImageDraw

RUN = Path(__file__).resolve().parents[1]
ATLAS = RUN / 'final/spritesheet-extended.png'
SKILL = Path('/root/.codex/plugins/cache/openai-curated-remote/work-pets/0.1.6/skills/create-pet/scripts')
STATES = [('idle',6),('running-right',8),('running-left',8),('waving',4),('jumping',5),('failed',8),('waiting',6),('running',6),('review',6)]

def main():
    if not ATLAS.exists():
        raise SystemExit('Finaler Atlas fehlt; keine Vorschauen erzeugt.')
    original = ATLAS.read_bytes()
    atlas = Image.open(ATLAS).convert('RGBA')
    if atlas.size != (1536,2288):
        raise SystemExit('Finaler Atlas besitzt nicht v2-Abmessungen.')
    frames_root = RUN / 'final/frames'
    previews = RUN / 'final/previews'
    previews.mkdir(parents=True,exist_ok=True)
    frames = {}
    for row,(state,count) in enumerate(STATES):
        state_dir = frames_root/state
        state_dir.mkdir(parents=True,exist_ok=True)
        frames[state] = []
        for col in range(count):
            cell=atlas.crop((col*192,row*208,(col+1)*192,(row+1)*208))
            cell.save(state_dir/f'{col:02d}.png')
            frames[state].append(cell)
    subprocess.run([sys.executable,str(SKILL/'render_animation_previews.py'),'--frames-root',str(frames_root),'--output-dir',str(previews)],check=True)
    sys.path.insert(0,str(SKILL))
    from render_animation_previews import ROW_DURATIONS, save_preview
    all_frames=[];durations=[]
    for state,_ in STATES:
        all_frames.extend(frames[state]);durations.extend(ROW_DURATIONS[state])
    save_preview(all_frames,durations,previews/'all-states.gif')
    # MP4 verwendet dieselben Zellpixel und Zeiten; transparenter Bereich wird dunkel hinterlegt.
    video_dir=previews/'video-frames';video_dir.mkdir(exist_ok=True)
    for i,frame in enumerate(all_frames):
        bg=Image.new('RGBA',(192,208),(20,20,28,255));bg.alpha_composite(frame)
        bg.convert('RGB').save(video_dir/f'{i:03d}.png')
    concat=video_dir/'concat.txt'
    lines=[]
    for i,duration in enumerate(durations):
        lines += [f"file '{i:03d}.png'",f'duration {duration/1000}']
    lines.append(f"file '{len(all_frames)-1:03d}.png'")
    concat.write_text('\n'.join(lines)+'\n')
    subprocess.run(['ffmpeg','-y','-loglevel','error','-f','concat','-safe','0','-i',str(concat),'-vf','fps=30','-c:v','libx264','-pix_fmt','yuv420p','-movflags','+faststart',str(previews/'all-states.mp4')],check=True)
    transition=frames['idle']+frames['jumping']+frames['idle']
    save_preview(transition,ROW_DURATIONS['idle']+ROW_DURATIONS['jumping']+ROW_DURATIONS['idle'],previews/'idle-jump-idle.gif')
    look=[]
    for row in (9,10):
        for col in range(8):
            look.append(atlas.crop((col*192,row*208,(col+1)*192,(row+1)*208)))
    save_preview(look,[160]*16,previews/'look-loop.gif')
    choices=[('idle',0),('waving',2),('jumping',2),('review',3)]
    still=Image.new('RGBA',(768,236),(20,20,28,255));draw=ImageDraw.Draw(still)
    for i,(state,n) in enumerate(choices):
        draw.text((i*192+8,7),f'{state} / frame {n+1}',fill='white')
        still.alpha_composite(frames[state][n],(i*192,28))
    still.save(previews/'animation-stills.png')
    if ATLAS.read_bytes()!=original:
        raise SystemExit('Finaler Atlas wurde unerwartet verändert.')
    report={'ok':True,'source':str(ATLAS),'sha256':hashlib.sha256(original).hexdigest(),'previews':str(previews),'frame_source':'exact final atlas cells','states':dict(STATES)}
    (previews/'preview-manifest.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
