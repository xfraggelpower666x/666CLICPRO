Create one horizontal animation strip for ChatGPT pet `cyberpunk-system-doctor-duo`, state `failed`.

Use the attached canonical base for identity. Use the attached layout guide only for slot count, spacing, centering, and padding; do not draw the guide.

Output exactly 8 full-body frames in one left-to-right row on flat pure green #00FF00. Treat the row as 8 invisible equal-width slots: one centered complete pose per slot, evenly spaced, with no overlap, clipping, empty slots, labels, or borders.

Identity: same pet in every frame: One inseparable duo pet: adult HUMAN doctor on viewer LEFT, small silver cyan violet robot JUNIOR on viewer RIGHT, junior maximum HALF doctor height; both whole bodies same ground baseline, short gap. Preserve all three user pair views: doctor brown swept hair black glasses short beard white tech coat graphite armor pink violet panels; junior crescent digital visor eyes triangular antenna ears cyan medical crosses wrist scanner. Every frame contains both complete characters as one close pose group. Never omit either, no added props, no detached effects, no shadows halos text or symbols. Preserve adult human proportions and detailed rendered reference style. Previous spritesheet is continuity reference for doctor animation only; new pair views define intended changed appearance.. Preserve silhouette, face, proportions, markings, palette, material, style, and props.
Style: Pet-safe sprite: compact full-body mascot, readable in a 192x208 cell, clear silhouette, simple face, stable palette/materials, and crisp edges for chroma-key extraction. Style `auto`: Infer the most appropriate pet-safe style from the user request and reference images, then keep that exact style consistent across every row.
Animation continuity: keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`. Move the pose within the slot instead of redrawing the pet larger or smaller frame to frame.

State action: Blocked/failed loop: slumped or deflated reaction with sad or closed eyes.

State requirements:
- Show failure through slumped pose, drooping ears/limbs, closed or sad eyes, and lower body position.
- Tears, small smoke puffs, or tiny stars are allowed only if attached to or overlapping the pet silhouette and kept inside the same frame slot.
- Do not draw red X marks, floating symbols, detached stars, separated smoke clouds, falling tear drops, dust, or other loose effects.

Clean extraction: crisp opaque edges, safe padding, no scenery, text, guide marks, checkerboard, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or chroma-key colors inside the pet.

DUO: every requested frame is ONE close complete doctor+junior pair, NOT alternating separate characters. Doctor LEFT and junior RIGHT in all front-facing states. Junior max half height. Generate exactly specified number of duo pose groups with broad gaps BETWEEN groups, only tiny gap INSIDE pair. Both characters perform corresponding state together. Pure green background #00FF00; no green in duo.
