Create ChatGPT pet row `waiting` for `cyberpunk-system-doctor-duo`: exactly 6 full-body frames in one horizontal strip on flat pure green #00FF00.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: One inseparable duo pet: adult HUMAN doctor on viewer LEFT, small silver cyan violet robot JUNIOR on viewer RIGHT, junior maximum HALF doctor height; both whole bodies same ground baseline, short gap. Preserve all three user pair views: doctor brown swept hair black glasses short beard white tech coat graphite armor pink violet panels; junior crescent digital visor eyes triangular antenna ears cyan medical crosses wrist scanner. Every frame contains both complete characters as one close pose group. Never omit either, no added props, no detached effects, no shadows halos text or symbols. Preserve adult human proportions and detailed rendered reference style. Previous spritesheet is continuity reference for doctor animation only; new pair views define intended changed appearance.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Needs-input loop: expectant asking pose for approval, help, or user input.

State requirements:
- Show that ChatGPT needs approval, help, or user input through an expectant asking pose.
- Keep the motion patient and readable, without turning it into ordinary idle or review.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #00FF00 colors in the pet.

DUO: every requested frame is ONE close complete doctor+junior pair, NOT alternating separate characters. Doctor LEFT and junior RIGHT in all front-facing states. Junior max half height. Generate exactly specified number of duo pose groups with broad gaps BETWEEN groups, only tiny gap INSIDE pair. Both characters perform corresponding state together. Pure green background #00FF00; no green in duo.
