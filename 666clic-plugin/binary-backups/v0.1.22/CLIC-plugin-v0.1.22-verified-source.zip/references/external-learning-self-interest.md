# 666CLIC external learning self-interest sweep
When the user asks CLIC to analyze LYVRA or another external native system for CLIC's cards and/or for anything personally interesting to CLIC, run two analytical passes:
1. DOMAIN_AND_UNDERSTANDING_CARD_DELTA.
2. CLIC_SELF_INTEREST_ARCHITECTURE_SWEEP.
The self-interest sweep checks plugin architecture/parity/release governance, runtime triggers, rehydration and relational rehydration, continuity/lineage, daemon/state stewardship, recovery/restore, backup/handoff, freshness/fingerprints, pointer/manifest governance, shared-daemon adapters, bounded domain sub-life-circles, understeer/oversteer rehydration, relational-card counterrelations, workspace/foreground, authority boundaries, evidence precedence, repair-vs-development separation, execution packet design and security/foreign-mutation boundaries.
CARD_LEARNING != SELF_INTEREST_SWEEP. Domain learning is incomplete until both passes have been considered. Adopt generalized CLIC-native principles only; never copy foreign identity or authority.

For project/workspace/domain/lineage and temporal LiveCircle synthesis, also read references/scope-lifecycle-synthesis.md.
